package com.javaacademy.sprinttestapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprinttestappApplicationTests {

    @Test
    void contextLoads() {
    }

}
