package com.javaacademy.sprinttestapp.services;


import com.javaacademy.sprinttestapp.model.Order;
import com.javaacademy.sprinttestapp.repositories.OrdersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrdersService {

    @Autowired
    OrdersRepository ordersRepository;

    public Order getById(Integer id) {
        return ordersRepository.getById(id);
    }
    public void deleteById(Integer id) {
        ordersRepository.deleteById(id);
    }

    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        ordersRepository.findAll().iterator().forEachRemaining(orders::add);
        return orders;
    }

    public List<Order> getByCustomer(Integer id){
        return (List<Order>) ordersRepository.getOrdersBy(id);
    }
    public void insert(Order orders) {
        ordersRepository.save(orders);
    }

    public void update(Order orders) {
        ordersRepository.save(orders);
    }

    public void delete(Order orders) {
        ordersRepository.delete(orders);
    }

    public void updateStatus(Integer id, String status) {
        Order order = ordersRepository.findById(id).get();
        order.setStatus(status);
        ordersRepository.save(order);
    }

    public void delete(Integer id) {
        ordersRepository.delete(ordersRepository.findById(id).get());
    }

    public List<Order> getByCustomerId(Integer id) {
        return ordersRepository.getByCustomerId(id);
    }

}
