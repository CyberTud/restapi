package com.javaacademy.sprinttestapp.repositories;


import com.javaacademy.sprinttestapp.model.Customer;
import com.javaacademy.sprinttestapp.model.Order;
import com.javaacademy.sprinttestapp.model.Order;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.awt.*;

@Repository
public interface OrdersRepository extends CrudRepository<Order, Integer> {
    public Order getById(Integer id);
    public void deleteById(Integer id);
    public List<Order> getOrdersBy(Integer id);

}