package com.javaacademy.sprinttestapp.controllers;


import com.javaacademy.sprinttestapp.model.Order;
import com.javaacademy.sprinttestapp.services.EmployeeService;
import com.javaacademy.sprinttestapp.services.OrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class OrdersController {

    @Autowired
    OrdersService ordersService;

    @GetMapping("/orders")
    public List<Order> getAllOrders() { return ordersService.getAllOrders(); }

    @GetMapping("/orders/{id}")
    public Order getOrdersById(@PathVariable Integer id) {
        return ordersService.getById(id);
    }

    @PostMapping("/orders")
    public Order createOrder(@RequestBody Order order) {
        ordersService.insert(order);
        return order;
    }

    @PostMapping("/orders/update")
    public Order updateOrder(@RequestBody Order order) {
        ordersService.update(order);
        return order;
    }

    @DeleteMapping("/orders/{id}")
    public void deleteOrderById(@PathVariable Integer id) {
        ordersService.deleteById(id);
    }

    @GetMapping("/orders/{id}/getByCustomerId")
    public List<Order> customerOrders(@PathVariable Integer id){
        return ordersService.getByCustomerId(id);

    }
}

