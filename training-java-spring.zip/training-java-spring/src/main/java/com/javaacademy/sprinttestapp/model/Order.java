package com.javaacademy.sprinttestapp.model;

import javax.persistence.*;

@Entity
@Table(name = "CustomerOrder")
public class Order {
    @Id
    @GeneratedValue
    private Integer order_id;
    private String name;
    private String status;
    @ManyToOne
    Customer customer;

    public Order(Integer order_id, String name, String status, Customer customer) {
        this.order_id = order_id;
        this.name = name;
        this.status = status;
        this.customer = customer;
    }

    public Order(Integer order_id, String name) {
        this.order_id = order_id;
        this.name = name;
    }

    public Order() {

    }

    public Integer getOrder_id() {
        return order_id;
    }

    public void setOrder_id(Integer order_id) {
        this.order_id = order_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
